extends CharacterBody3D

@export var speed := 5.5
@export var gravity := 18.0

func _physics_process(delta):
    var input_dir = Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    var direction = Vector3(input_dir.x, 0, input_dir.y).normalized()
    if direction.length() > 0:
        velocity.x = direction.x * speed
        velocity.z = direction.z * speed
        look_at(global_position + direction, Vector3.UP)
    else:
        velocity.x = move_toward(velocity.x, 0, speed * 5 * delta)
        velocity.z = move_toward(velocity.z, 0, speed * 5 * delta)
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0
    move_and_slide()

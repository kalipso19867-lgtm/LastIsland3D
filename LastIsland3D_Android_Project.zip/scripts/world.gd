extends Node3D

const PlayerScript = preload("res://scripts/player.gd")
var player
var hud
var wood := 0
var stone := 0
var berries := 0
var collected := {}
var resource_nodes := []

func _ready():
    _make_environment()
    _make_island()
    _make_resources()
    _make_player()
    _make_hud()
    _load_game()

func _make_environment():
    var env = WorldEnvironment.new()
    var e = Environment.new()
    e.background_mode = Environment.BG_SKY
    e.sky = Sky.new()
    e.sky.sky_material = ProceduralSkyMaterial.new()
    e.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    e.ambient_light_color = Color(0.72, 0.82, 1.0)
    e.ambient_light_energy = 0.8
    e.tonemap_mode = Environment.TONE_MAPPER_FILMIC
    env.environment = e
    add_child(env)
    var sun = DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -32, 0)
    sun.light_energy = 1.25
    sun.shadow_enabled = true
    add_child(sun)
    var water = MeshInstance3D.new()
    var wm = PlaneMesh.new()
    wm.size = Vector2(150, 150)
    water.mesh = wm
    water.position.y = -1.5
    var mat = StandardMaterial3D.new()
    mat.albedo_color = Color(0.04, 0.38, 0.58)
    mat.roughness = 0.28
    water.material_override = mat
    add_child(water)

func _mat(color: Color, roughness := 0.9):
    var m = StandardMaterial3D.new()
    m.albedo_color = color
    m.roughness = roughness
    return m

func _make_island():
    var ground = MeshInstance3D.new()
    var sphere = SphereMesh.new()
    sphere.radius = 1.0
    sphere.height = 2.0
    ground.mesh = sphere
    ground.scale = Vector3(17, 2.5, 14)
    ground.position.y = -0.3
    ground.material_override = _mat(Color(0.28, 0.48, 0.20))
    add_child(ground)
    var sand = MeshInstance3D.new()
    var sm = SphereMesh.new()
    sand.mesh = sm
    sand.scale = Vector3(17.1, 0.65, 14.1)
    sand.position.y = -1.0
    sand.material_override = _mat(Color(0.78, 0.68, 0.43))
    add_child(sand)
    # A simple campsite landmark
    _make_tree(Vector3(-5, 0.9, -4), 1.25)
    _make_tree(Vector3(6, 0.9, -5), 1.0)
    _make_tree(Vector3(8, 0.9, 4), 1.15)
    _make_tree(Vector3(-8, 0.9, 4), 0.9)
    _make_tree(Vector3(0, 0.9, -8), 1.0)

func _make_tree(pos: Vector3, size: float):
    var trunk = MeshInstance3D.new()
    var cm = CylinderMesh.new()
    cm.top_radius = 0.22 * size
    cm.bottom_radius = 0.32 * size
    cm.height = 2.0 * size
    trunk.mesh = cm
    trunk.position = pos
    trunk.material_override = _mat(Color(0.34, 0.18, 0.08))
    add_child(trunk)
    var crown = MeshInstance3D.new()
    var cone = SphereMesh.new()
    crown.mesh = cone
    crown.scale = Vector3(1.25, 1.15, 1.25) * size
    crown.position = pos + Vector3(0, 1.45 * size, 0)
    crown.material_override = _mat(Color(0.08, 0.34, 0.16))
    add_child(crown)

func _make_rock(pos: Vector3, scale_v: Vector3):
    var rock = MeshInstance3D.new()
    var mesh = SphereMesh.new()
    rock.mesh = mesh
    rock.scale = scale_v
    rock.position = pos
    rock.material_override = _mat(Color(0.38, 0.42, 0.43))
    add_child(rock)

func _make_resources():
    var spots = [
        ["wood", Vector3(-3, 0.8, 2)], ["wood", Vector3(4, 0.8, 2)],
        ["wood", Vector3(-9, 0.8, -1)], ["stone", Vector3(2, 0.8, -3)],
        ["stone", Vector3(-5, 0.8, 7)], ["stone", Vector3(9, 0.8, -1)],
        ["berry", Vector3(0, 0.8, 6)], ["berry", Vector3(6, 0.8, 7)]
    ]
    for i in range(spots.size()):
        var kind = spots[i][0]
        var p: Vector3 = spots[i][1]
        var node = Area3D.new()
        node.name = "Resource_%d" % i
        node.position = p
        node.set_meta("kind", kind)
        node.set_meta("resource_id", str(i))
        var shape = CollisionShape3D.new()
        var sphere = SphereShape3D.new()
        sphere.radius = 1.35
        shape.shape = sphere
        node.add_child(shape)
        var visual = MeshInstance3D.new()
        if kind == "wood":
            var box = BoxMesh.new()
            box.size = Vector3(0.75, 0.45, 0.45)
            visual.mesh = box
            visual.material_override = _mat(Color(0.48, 0.25, 0.10))
        elif kind == "stone":
            visual.mesh = SphereMesh.new()
            visual.scale = Vector3(0.65, 0.5, 0.6)
            visual.material_override = _mat(Color(0.48, 0.52, 0.55))
        else:
            visual.mesh = SphereMesh.new()
            visual.scale = Vector3(0.45, 0.4, 0.45)
            visual.material_override = _mat(Color(0.65, 0.12, 0.22))
        visual.position.y = 0.35
        node.add_child(visual)
        add_child(node)
        resource_nodes.append(node)

func _make_player():
    player = CharacterBody3D.new()
    player.name = "Player"
    player.set_script(PlayerScript)
    player.position = Vector3(0, 2.5, 0)
    add_child(player)
    var camera_pivot = Node3D.new()
    camera_pivot.name = "CameraPivot"
    camera_pivot.position = Vector3(0, 1.1, 0)
    player.add_child(camera_pivot)
    var camera = Camera3D.new()
    camera.position = Vector3(0, 5.5, 9)
    camera.rotation_degrees = Vector3(-27, 0, 0)
    camera.current = true
    camera_pivot.add_child(camera)
    var body = MeshInstance3D.new()
    var capsule = CapsuleMesh.new()
    capsule.radius = 0.42
    capsule.height = 1.7
    body.mesh = capsule
    body.position.y = 0.85
    body.material_override = _mat(Color(0.93, 0.55, 0.22))
    player.add_child(body)
    var collision = CollisionShape3D.new()
    var cs = CapsuleShape3D.new()
    cs.radius = 0.42
    cs.height = 1.7
    collision.shape = cs
    collision.position.y = 0.85
    player.add_child(collision)

func _make_hud():
    hud = CanvasLayer.new()
    add_child(hud)
    var panel = PanelContainer.new()
    panel.position = Vector2(18, 18)
    panel.custom_minimum_size = Vector2(260, 110)
    hud.add_child(panel)
    var v = VBoxContainer.new()
    panel.add_child(v)
    var title = Label.new()
    title.text = "ПОСЛЕДНИЙ ОСТРОВ 3D"
    title.add_theme_font_size_override("font_size", 20)
    v.add_child(title)
    var stats = Label.new()
    stats.name = "Stats"
    stats.text = "Дерево: 0   Камень: 0\nЯгоды: 0"
    v.add_child(stats)
    var hint = Label.new()
    hint.text = "Подойди к ресурсу и нажми «СОБРАТЬ»"
    v.add_child(hint)
    var collect = Button.new()
    collect.text = "СОБРАТЬ"
    collect.position = Vector2(0, 0)
    collect.custom_minimum_size = Vector2(190, 62)
    collect.anchor_left = 1.0
    collect.anchor_right = 1.0
    collect.anchor_top = 1.0
    collect.anchor_bottom = 1.0
    collect.offset_left = -215
    collect.offset_right = -18
    collect.offset_top = -95
    collect.offset_bottom = -25
    collect.pressed.connect(_collect_nearest)
    hud.add_child(collect)
    var controls = Label.new()
    controls.text = "WASD / экранные кнопки"
    controls.position = Vector2(20, 140)
    hud.add_child(controls)
    _add_touch_controls()

func _add_touch_controls():
    var dirs = [
        ["▲", Vector2(100, -190), "move_forward"],
        ["▼", Vector2(100, -55), "move_back"],
        ["◀", Vector2(30, -122), "move_left"],
        ["▶", Vector2(170, -122), "move_right"]
    ]
    for d in dirs:
        var b = TouchMoveButton.new()
        b.text = d[0]
        b.action = d[2]
        b.custom_minimum_size = Vector2(62, 62)
        b.anchor_left = 0
        b.anchor_right = 0
        b.anchor_top = 1
        b.anchor_bottom = 1
        b.offset_left = d[1].x
        b.offset_right = d[1].x + 62
        b.offset_top = d[1].y
        b.offset_bottom = d[1].y + 62
        hud.add_child(b)

func _collect_nearest():
    var nearest = null
    var best = 3.0
    for n in resource_nodes:
        if not is_instance_valid(n) or collected.has(n.get_meta("resource_id")):
            continue
        var dist = player.global_position.distance_to(n.global_position)
        if dist < best:
            best = dist
            nearest = n
    if nearest == null:
        _set_hint("Подойди ближе к дереву, камню или ягодам")
        return
    var id = nearest.get_meta("resource_id")
    var kind = nearest.get_meta("kind")
    collected[id] = true
    if kind == "wood":
        wood += 3
    elif kind == "stone":
        stone += 2
    else:
        berries += 2
    nearest.queue_free()
    resource_nodes.erase(nearest)
    _update_stats()
    _set_hint("Ресурс собран! Прогресс сохранён.")
    _save_game()

func _set_hint(value: String):
    var hint = get_node_or_null("HUDHint")
    if hint:
        hint.text = value

func _update_stats():
    var stats = hud.get_node_or_null("PanelContainer/VBoxContainer/Stats")
    if stats:
        stats.text = "Дерево: %d   Камень: %d\nЯгоды: %d" % [wood, stone, berries]

func _save_game():
    var cfg = ConfigFile.new()
    cfg.set_value("inventory", "wood", wood)
    cfg.set_value("inventory", "stone", stone)
    cfg.set_value("inventory", "berries", berries)
    cfg.set_value("world", "collected", collected.keys())
    cfg.save("user://save.cfg")

func _load_game():
    var cfg = ConfigFile.new()
    if cfg.load("user://save.cfg") != OK:
        return
    wood = int(cfg.get_value("inventory", "wood", 0))
    stone = int(cfg.get_value("inventory", "stone", 0))
    berries = int(cfg.get_value("inventory", "berries", 0))
    var old: Array = cfg.get_value("world", "collected", [])
    for id in old:
        collected[str(id)] = true
        for n in resource_nodes.duplicate():
            if n.get_meta("resource_id") == str(id):
                resource_nodes.erase(n)
                n.queue_free()
    _update_stats()

func _process(_delta):
    pass

class TouchMoveButton:
    extends Button
    var action := ""
    var held := false
    func _ready():
        button_down.connect(func(): Input.action_press(action))
        button_up.connect(func(): Input.action_release(action))
        focus_mode = Control.FOCUS_NONE
